"""Compare shared SD thresholds on all three complete real recordings.

No burst, prefix-only fit, per-channel thresholds, RTL changes or config writes.
The score is agreement with the available curated reference, not biological truth.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_OUT = ROOT/'build/training/threshold_sweep'
TOLS = (8, 16, 32)
PRIMARY_TOL = 16
REFRACTORY = 63
COEFFICIENTS = [0.5] + list(range(1,129)) + list(range(144,257,16))
FORMULAS = {
    'fixed': 'T = constant',
    'mean_neo': 'T = ceil(k * mean(NEO))',
    'median_abs_neo': 'T = ceil(k * median(abs(NEO)))',
    'median_mad_neo': 'T = ceil(median(NEO) + k * median(abs(NEO-median(NEO))) / 0.6744897501960817)',
    'mean_std_neo': 'T = ceil(mean(NEO) + k * std(NEO))',
    'std_neo': 'T = ceil(k * std(NEO))',
    'raw_mad_squared': 'T = ceil(k * (median(abs(x-median_channel(x))) / 0.6744897501960817)**2)',
    'quantile_neo': 'T = ceil(quantile(NEO, q))',
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def load_refs(path, n):
    result = [[] for _ in range(16)]
    for r in rows(path):
        t = int(r['timestamp'])
        if 0 <= t < n:
            result[int(r['channel_id'])].append(t)
    return [np.sort(np.array(r, dtype=np.int64)) for r in result]


def detect(neo, threshold):
    result = []
    for channel in range(16):
        candidates = np.flatnonzero(neo[channel] >= threshold) + 1
        last, events = -100000, []
        for t in candidates:
            # SD is allowed only after 32 earlier samples have arrived.
            if t >= 32 and t-last > REFRACTORY:
                events.append(int(t))
                last = t
        result.append(np.asarray(events, dtype=np.int64))
    return result


def matches(detections, references, tolerance):
    # Maximum-cardinality, same-channel, one-to-one interval matching.
    i = count = 0
    for t in references:
        i = max(i, int(np.searchsorted(detections, t-tolerance)))
        if i < len(detections) and detections[i] <= t+tolerance:
            i += 1
            count += 1
    return count


def score(ds, refs, tol):
    hit = sum(matches(d, r, tol) for d, r in zip(ds, refs))
    nd, nr = sum(map(len, ds)), sum(map(len, refs))
    return dict(detected=nd, reference=nr, matched=hit,
                missed_reference=nr-hit, unmatched_detection=nd-hit,
                reference_recall=hit/nr if nr else 0.,
                reference_precision=hit/nd if nd else 0.,
                reference_f1=2*hit/(nd+nr) if nd+nr else 0.)


def statistics(x):
    z = x[:, 1:-1]**2 - x[:, :-2]*x[:, 2:]
    m = float(np.median(z))
    centered = x-np.median(x, axis=1, keepdims=True)
    return dict(mean=float(np.mean(z)), std=float(np.std(z)), median=m,
                median_abs=float(np.median(np.abs(z))),
                mad=float(np.median(np.abs(z-m)))/0.6744897501960817,
                raw_sigma=float(np.median(np.abs(centered)))/0.6744897501960817,
                quantile={str(q):float(np.quantile(z,q)) for q in QUANTILES})


QUANTILES = [0.95, 0.975, 0.98] + [v/100000 for v in range(99000,100000,5)]


def threshold_from_stats(method, parameter, stats):
    k = parameter
    values = {'fixed': k,
              'mean_neo': k*stats['mean'],
              'median_abs_neo': k*stats['median_abs'],
              'median_mad_neo': stats['median']+k*stats['mad'],
              'mean_std_neo': stats['mean']+k*stats['std'],
              'std_neo': k*stats['std'],
              'raw_mad_squared': k*stats['raw_sigma']**2}
    value = stats['quantile'][str(k)] if method=='quantile_neo' else values[method]
    return min(0xffffffff, max(1, int(np.ceil(value))))


def candidates():
    result = [('fixed',15000)]
    result += [('fixed',k) for k in list(range(250,15000,250))+[20000,30000,50000]]
    for method in ['mean_neo','median_abs_neo','median_mad_neo','raw_mad_squared']:
        result += [(method,k) for k in COEFFICIENTS]
    result += [('mean_std_neo',k/4) for k in range(1,129)]
    result += [('std_neo',k/4) for k in range(1,129)]
    result += [('quantile_neo',q) for q in QUANTILES]
    return [dict(method=m,parameter=k,key=f'{m}:{k:g}',formula=FORMULAS[m]) for m,k in result]


def save_csv(path, records):
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(records[0]))
        w.writeheader();w.writerows(records)


def rank(cases, names):
    return sorted(cases, key=lambda r: (-np.mean([r['datasets'][n]['scores']['16']['reference_f1'] for n in names]),
                                      -min(r['datasets'][n]['scores']['16']['reference_f1'] for n in names),
                                      r['key']))


def select_noise_coefficient(metrics):
    """Reproduce the adopted raw-noise rule from the comparison table.

    Same criterion as the original threshold analysis: highest mean reference
    recall, then fewest detections. Sorter waveform diagnostics are separate.
    """
    relevant = [r for r in metrics
                if r['method'] == 'raw_mad_squared'
                and int(r['tolerance_samples']) == PRIMARY_TOL]
    names = sorted({r['dataset'] for r in relevant})
    parameters = sorted({float(r['parameter']) for r in relevant})

    def choose(training_names):
        def key(parameter):
            group = [r for r in relevant if float(r['parameter']) == parameter
                     and r['dataset'] in training_names]
            return (-float(np.mean([float(r['reference_recall']) for r in group])),
                    sum(int(r['detected']) for r in group), parameter)
        return min(parameters, key=key)

    folds = []
    for name in names:
        k = choose([n for n in names if n != name])
        row = next(r for r in relevant if r['dataset'] == name
                   and float(r['parameter']) == k)
        folds.append(dict(held_out=name, k_selected_on_other_two=k,
                          recall=float(row['reference_recall']),
                          matched=int(row['matched']), reference=int(row['reference']),
                          detected=int(row['detected'])))
    return dict(
        criterion='Maximize mean curated-reference recall across recordings, NOT incomplete-reference F1. Tie: fewer detector events.',
        common_k=choose(names), leave_one_recording_out=folds)


def regression_checks(data):
    # Compare exact event timestamps to the previously validated Golden at its threshold.
    for name, d in data.items():
        cfg=ROOT/'data/prepared'/name
        t=json.loads((cfg/'metadata.json').read_text(encoding='utf-8'))['threshold']
        ds=detect(d['neo'],t)
        expected=load_refs(cfg/'mainpath_golden.csv',d['n']+32)
        for a,b in zip(ds,expected):
            np.testing.assert_array_equal(a,b)
    assert matches(np.array([10]),np.array([9,11]),2)==1
    assert matches(np.array([10,12]),np.array([11]),2)==1
    assert matches(np.array([10,12]),np.array([11,13]),2)==2
    assert matches(np.array([10]),np.array([30]),2)==0


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--data-root',type=Path,default=ROOT/'data/recordings')
    ap.add_argument('--output',type=Path,default=DEFAULT_OUT)
    ap.add_argument('--check-only', action='store_true', help='Check inputs and Golden without sweeping or writing files')
    args=ap.parse_args();out=args.output
    data={};sources=[]
    for i in range(1,4):
        name=f'real{i}';src=args.data_root/name
        audit=src/'reference_audit'
        info=json.loads((audit/'audit.json').read_text())
        assert info['original_reference_sha256']==sha(src/'reference_spikes.csv')
        x=np.load(src/'processed_ap_uV_int16.npy').astype(np.int64)
        assert x.shape[0]==16
        raw=np.load(src/'original_raw_ap_volts.npz')
        padded=np.pad(x,((0,0),(0,32)),mode='edge')
        z=padded[:,1:-1]**2-padded[:,:-2]*padded[:,2:]
        data[name]=dict(n=x.shape[1],neo=z,stats=statistics(x),
                        refs=load_refs(audit/'reference_sample_indices.csv',x.shape[1]),
                        old_refs=load_refs(src/'reference_spikes.csv',x.shape[1]))
        # Validate the numerical array against every row actually sent to RTL.
        records=np.loadtxt(src/'input.csv',delimiter=',',skiprows=1,dtype=np.int64)
        np.testing.assert_array_equal(records[:,3].reshape(-1,16).T,x)
        np.testing.assert_array_equal(records[:,0],np.repeat(np.arange(x.shape[1]),16))
        np.testing.assert_array_equal(records[:,1],np.tile(np.arange(16),x.shape[1]))
        assert np.all(records[:,2]==1)
        sources.append(dict(dataset=name,input=str(src/'input.csv'),input_sha256=sha(src/'input.csv'),
                            reference=str(audit/'reference_sample_indices.csv'),
                            reference_sha256=sha(audit/'reference_sample_indices.csv'),
                            rows=int(x.size),samples_per_channel=x.shape[1],
                            sample_rate_hz=float(raw['sample_rate_hz']),stats=data[name]['stats'],
                            time_correction=[info['correction_min'],info['correction_max']]))
    regression_checks(data)
    print('PASS: CSV/NPY agreement, detector/Golden exact agreement, matching unit checks',flush=True)
    if args.check_only:
        return
    out.mkdir(parents=True,exist_ok=True)
    grid=candidates();cases=[];metrics=[];cache={n:{} for n in data}
    for index,candidate in enumerate(grid):
        item={**candidate,'datasets':{}}
        for name,d in data.items():
            t=threshold_from_stats(candidate['method'],candidate['parameter'],d['stats'])
            if t not in cache[name]:
                ds=detect(d['neo'],t)
                cache[name][t]=dict(threshold=t,scores={str(tol):score(ds,d['refs'],tol) for tol in TOLS},
                                    old_reference_score16=score(ds,d['old_refs'],16))
            item['datasets'][name]=cache[name][t]
            for tol in TOLS:
                metrics.append(dict(method=candidate['method'],parameter=candidate['parameter'],
                                    dataset=name,threshold=t,tolerance_samples=tol,
                                    **cache[name][t]['scores'][str(tol)]))
        item['macro_f1']=float(np.mean([r['scores']['16']['reference_f1'] for r in item['datasets'].values()]))
        cases.append(item)
        if index%200==0:print(f'Compared {index+1}/{len(grid)} candidates',flush=True)
    ordered=rank(cases,list(data))
    best=ordered[0]
    best_by_family=[]
    for family in FORMULAS:
        chosen=next(r for r in ordered if r['method']==family)
        best_by_family.append(chosen)
    automatic=[r for r in ordered if r['method']!='fixed']
    selected=automatic[0]
    loo=[]
    for heldout in data:
        training=[n for n in data if n!=heldout]
        choice=rank([r for r in cases if r['method']!='fixed'],training)[0]
        loo.append(dict(held_out=heldout,selected_on_other_two=choice['key'],
                        **choice['datasets'][heldout]['scores']['16']))
    family_loo=[]
    for family in FORMULAS:
        values=[]
        for heldout in data:
            training=[n for n in data if n!=heldout]
            choice=rank([r for r in cases if r['method']==family],training)[0]
            values.append(dict(held_out=heldout,parameter=choice['parameter'],
                               **choice['datasets'][heldout]['scores']['16']))
        family_loo.append(dict(method=family,folds=values,
                               macro_f1=float(np.mean([r['reference_f1'] for r in values]))))
    # Check chance matches for the selected automatic rule, fixed baseline, and old rule.
    chance=[]
    rng=np.random.default_rng(20260909)
    for candidate in [selected,next(r for r in cases if r['key']=='fixed:15000'),
                      next(r for r in cases if r['key']=='mean_neo:4')]:
        for name,d in data.items():
            ds=detect(d['neo'],candidate['datasets'][name]['threshold'])
            counts=[]
            for shifts in rng.integers(1000,d['n']-1000,size=(200,16)):
                shifted=[np.sort((events+shift)%d['n']) for events,shift in zip(ds,shifts)]
                counts.append(score(shifted,d['refs'],16)['matched'])
            chance.append(dict(method=candidate['key'],dataset=name,
                               actual_matched=score(ds,d['refs'],16)['matched'],
                               shifted_mean=float(np.mean(counts)),
                               shifted_p95=float(np.quantile(counts,.95))))
    result=dict(validation=dict(csv_matches_numpy=True,detector_events_match_existing_goldens=True,
                                one_to_one_matching_unit_checks=True),
                condition='All samples of real1/2/3 only; one shared threshold per dataset; refractory63.',
                criterion='Maximize unweighted mean of three per-recording reference F1 scores at +/-16 samples. Fixed global coefficient; never tune each recording separately.',
                limitations=['Curated reference is incomplete: unmatched detections are not proven false positives.',
                             'Full-record fit scores are development/selection results, not independent test accuracy.',
                             'Leave-one-recording-out scores test transfer of the formula/constant, still using each recording whole for its unsupervised noise statistic.',
                             'Only 3 one-second recordings are available. No claim of universal optimality.',
                             'Reference timestamps corrected from official sample indices, not waveform fitting.',
                             'Pooled 16-channel threshold is our hardware adaptation. Some method families are statistical comparison variants, not exact reproductions of a paper.'],
                sources=sources,candidate_count=len(grid),dataset_evaluations=len(grid)*3,
                baseline_15000=next(r for r in cases if r['key']=='fixed:15000'),
                old_mean4=next(r for r in cases if r['key']=='mean_neo:4'),
                literature_median18=next(r for r in cases if r['key']=='median_abs_neo:18'),
                literature_std3=next(r for r in cases if r['key']=='std_neo:3'),
                best_overall=best,best_automatic=selected,best_by_family=best_by_family,
                leave_one_recording_out=loo,family_leave_one_recording_out=family_loo,
                chance_alignment=chance,
                ranking=[dict(key=r['key'],macro_f1=r['macro_f1']) for r in ordered])
    (out/'comparison.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
    save_csv(out/'all_candidates.csv',metrics)
    comparisons=[]
    wanted=[result['baseline_15000'],result['old_mean4'],result['literature_median18'],result['literature_std3']]+best_by_family
    seen=set()
    for r in wanted:
        if r['key'] in seen:continue
        seen.add(r['key'])
        for name,d in r['datasets'].items():
            comparisons.append(dict(method=r['method'],parameter=r['parameter'],dataset=name,
                                    threshold=d['threshold'],**d['scores']['16'],macro_f1=r['macro_f1']))
    save_csv(out/'method_comparison.csv',comparisons)
    choice=dict(status='Historical F1 comparison winner. The adopted raw-noise coefficient is recorded separately in coefficient_selection.json.',
                method=selected['method'],parameter=selected['parameter'],formula=selected['formula'],
                shared_across_channels=True,reference_required_at_runtime=False,
                formula_selection_samples='All samples of three real recordings; no burst.',
                threshold_by_dataset={n:d['threshold'] for n,d in selected['datasets'].items()},
                macro_reference_f1=selected['macro_f1'],
                runtime_prefix_validation='Not performed in this formula-selection experiment.',
                files_changed='Comparison artifacts only; production configuration, RTL, Golden, XSA, and board software untouched.')
    (out/'best_f1_formula.json').write_text(json.dumps(choice,indent=2),encoding='utf-8')
    selection = select_noise_coefficient(metrics)
    (out/'coefficient_selection.json').write_text(json.dumps(selection,indent=2),encoding='utf-8')
    print('BEST OVERALL',best['key'],best['macro_f1'],flush=True)
    print('BEST AUTOMATIC',selected['key'],selected['macro_f1'],flush=True)
    for n,d in selected['datasets'].items():print(n,d['threshold'],d['scores']['16'],flush=True)
    print('LOO',loo,flush=True)
    print('RAW-NOISE COEFFICIENT', selection['common_k'], flush=True)


if __name__=='__main__':
    main()
