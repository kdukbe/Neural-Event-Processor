"""Rebuild reference sample positions from the preserved IBL source arrays.

Input: data/recordings/real*/input metadata, reference_spikes.csv, raw/processed
arrays, and reference_audit/public_spike_slice.npz + public_datasets.json.
Output: build/training/reference_audit/real*/reference_sample_indices.csv,
audit.json and public_datasets.json. Source recordings remain unchanged.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[2]


def rebuild(source, target):
    metadata = json.loads((source/'metadata.json').read_text(encoding='utf-8'))
    audit_source = source/'reference_audit'
    public = json.loads((audit_source/'public_datasets.json').read_text(encoding='utf-8'))
    with np.load(source/'original_raw_ap_volts.npz') as raw:
        first = int(raw['first_sample'])
        fs = float(raw['sample_rate_hz'])
    with np.load(audit_source/'public_spike_slice.npz') as saved:
        first_index = int(saved['first_index'])
        arrays = {key: saved[key].copy() for key in ('times', 'samples', 'clusters')}
    if len({len(values) for values in arrays.values()}) != 1:
        raise ValueError('Public spike arrays have different lengths')
    start, _ = metadata['selection']['selected_interval_s']
    with (source/'reference_spikes.csv').open(encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    corrected = []
    for row in rows:
        old = int(row['timestamp'])
        cluster = int(row['spike_class'])-1
        indices = np.flatnonzero((arrays['clusters'] == cluster)
            & (np.rint((arrays['times']-start)*fs).astype('int64') == old))
        if len(indices) != 1:
            raise ValueError(f'Expected one source spike for {source.name}: {row}')
        index = int(indices[0])
        actual = int(arrays['samples'][index])-first
        corrected.append({**{key: int(value) for key, value in row.items()},
            'original_timestamp': old, 'timestamp': actual,
            'sample_index_correction': actual-old,
            'source_spike_index': first_index+index,
            'session_time': float(arrays['times'][index])})
    x = np.load(source/'processed_ap_uV_int16.npy')
    for row in corrected:
        t = row['timestamp']
        row['sample'] = int(x[row['channel_id'], t]) if 0 <= t < x.shape[1] else ''
    if not corrected:
        raise ValueError(f'No reference spikes: {source}')
    target.mkdir(parents=True, exist_ok=True)
    with (target/'reference_sample_indices.csv').open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(corrected[0]))
        writer.writeheader()
        writer.writerows(corrected)
    changes = [row['sample_index_correction'] for row in corrected]
    result = dict(dataset=source.name, source_datasets=public,
        downloaded_spike_index_range=[first_index, first_index+len(arrays['times'])],
        original_reference_sha256=hashlib.sha256((source/'reference_spikes.csv').read_bytes()).hexdigest(),
        correction_rule='spikes.samples - raw slice first_sample. No waveform-fitted shift.',
        actual_raw_first_sample=first, actual_raw_sample_rate_hz=fs,
        metadata_first_sample=metadata['selection']['first_sample'], count=len(rows),
        correction_min=min(changes), correction_max=max(changes),
        correction_median=float(np.median(changes)),
        outside_input_count=sum(not 0 <= row['timestamp'] < x.shape[1] for row in corrected),
        original_files_modified=False)
    (target/'audit.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    (target/'public_datasets.json').write_text(json.dumps(public, indent=2), encoding='utf-8')
    print(f'{source.name}: rebuilt {len(corrected)} reference positions -> {target}', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root', type=Path, default=ROOT/'data/recordings')
    parser.add_argument('--output', type=Path, default=ROOT/'build/training/reference_audit')
    parser.add_argument('--datasets', nargs='+', choices=('real1', 'real2', 'real3'), default=('real1', 'real2', 'real3'))
    args = parser.parse_args()
    if args.output.resolve().is_relative_to(args.data_root.resolve()):
        parser.error('Choose an output outside the preserved recordings directory')
    for dataset in args.datasets:
        rebuild(args.data_root/dataset, args.output/dataset)


if __name__ == '__main__':
    main()
