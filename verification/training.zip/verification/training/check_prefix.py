"""Check fixed initial sample counts without changing production inputs/configs."""
import argparse
from pathlib import Path
from collections import Counter
import sys
import json
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=ROOT/'build/training/threshold_selection'
DATA_ROOT=ROOT/'data/recordings'
import reference_model as model
from processing import threshold as calc
import compare_thresholds as sweep

LENGTHS=[512,1024,2048,4096,8192,16384,20000,24576,30000,32768]


def main():
    global HERE, DATA_ROOT
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root',type=Path,default=DATA_ROOT)
    parser.add_argument('--output',type=Path,default=HERE)
    args=parser.parse_args();HERE=args.output;DATA_ROOT=args.data_root
    HERE.mkdir(parents=True,exist_ok=True)
    model.set_channel_count(16)
    rows=[];detail=[];checks=[]
    for i in range(1,4):
        name=f'real{i}';src=DATA_ROOT/name
        x=np.load(src/'processed_ap_uV_int16.npy').astype(np.int64)
        total=x.shape[1];pad=np.pad(x,((0,0),(0,32)),mode='edge')
        z=pad[:,1:-1]**2-pad[:,:-2]*pad[:,2:]
        rp=src/'reference_audit/reference_sample_indices.csv'
        refs=sweep.load_refs(rp,total)
        keys=['event_id','timestamp','channel_id','spike_class']
        truth=[{k:int(r[k]) for k in keys} for r in sweep.rows(rp) if 0<=int(r['timestamp'])<total]
        full=calc.calculate(src/'input.csv',samples_per_channel=0)['threshold']
        for requested in LENGTHS:
            n=min(requested,total);xx=x[:,:n]
            centered=xx-np.median(xx,axis=1,keepdims=True)
            sigma=float(np.median(np.abs(centered)))/calc.NORMAL_MEDIAN_ABS
            th=max(1,min(0xffffffff,int(np.ceil(calc.COEFFICIENT*sigma*sigma))))
            ds=sweep.detect(z,th);scores=sweep.score(ds,refs,16)
            suffix=sweep.score([t[t>=n] for t in ds],[t[t>=n] for t in refs],16)
            channels={ch:model.ChannelSamples(np.arange(n),x[ch,:n]) for ch in range(16)}
            ev,_=model.detect_events(name,channels,th,63,model.DEFAULT_COEFFICIENTS)
            labels=[r for r in truth if r['timestamp']<n]
            model.attach_labels(ev,labels,16)
            counters=[Counter(e.spike_class for e in ev if e.channel_id==ch and e.spike_class>0) for ch in range(16)]
            # Existing code's minimum for mathematical computability only.
            # Two events/class do NOT establish reliable feature learning.
            computable=sum(sum(v>=2 for v in c.values())>=2 for c in counters)
            rows.append(dict(dataset=name,requested_samples_per_channel=requested,used_samples_per_channel=n,
                             calibration_rows=n*16,threshold=th,full_threshold=full,
                             threshold_same_as_full=th==full,detected=scores['detected'],
                             known_matched=scores['matched'],known_reference=scores['reference'],
                             remaining_matched=suffix['matched'],remaining_reference=suffix['reference'],
                             feature_minimum_computable_channels=computable,
                             matched_training_events=sum(sum(c.values()) for c in counters)))
            if requested in (20000,30000):
                for ch,c in enumerate(counters):
                    detail.append(dict(dataset=name,samples_per_channel=n,channel=ch,
                                       class_counts=json.dumps(dict(c)),
                                       minimum_computable=sum(v>=2 for v in c.values())>=2))
            if requested==20000:
                cli=calc.calculate(src/'input.csv',samples_per_channel=requested)
                assert cli['threshold']==th and cli['samples_per_channel']==[n]*16
                checks.append(dict(dataset=name,threshold=th,csv_numpy_identical=True))
        print(name,'PASS',flush=True)
    sweep.save_csv(HERE/'prefix_comparison.csv',rows)
    sweep.save_csv(HERE/'prefix_feature_availability.csv',detail)
    eligible=[n for n in LENGTHS if all(r['threshold_same_as_full'] for r in rows if r['requested_samples_per_channel']==n)]
    result=dict(recommended_samples_per_channel=20000,first_matching_tested_length=min(eligible),
                channels=16,total_requested_rows=320000,short_file_policy='Use all available valid samples in each channel; require at least three.',
                criterion='First tested prefix that reproduces each full-record threshold on all three current real recordings.',
                caution='Chosen with knowledge of the full three recordings; not independent validation or a universal minimum. Feature-learning sufficiency is separate.',
                formula_unchanged=True,checks=checks,production_configs_changed=False)
    (HERE/'prefix_selection.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
