# Threshold · Feature 선정 근거 재현

`SW/python`은 사용할 설정값을 만드는 코드이고, 이 폴더는 **그 계산 방식을 선택한 근거를 확인하는 평가 코드**이다. 프로젝트 최상위 폴더에서 실행한다. 새 결과는 `build/training`에 저장된다.

```powershell
python -m pip install -r verification/training/requirements.txt
```

| 실행 파일 | 입력 | 출력 · 목적 |
|---|---|---|
| `audit_reference.py` | `data/recordings/real1~3`의 원본 Reference와 보존된 IBL Sample 번호 | `reference_audit/<데이터>/reference_sample_indices.csv` 등: 입력 Sample 번호에 맞는 Reference 재생성 |
| `compare_thresholds.py` | 실제 Sample·Reference·기존 Golden | `threshold_sweep`: Threshold 공식·계수별 검출 수, 일치·누락 수, Precision·Recall·F1 비교 |
| `check_prefix.py` | 실제 입력·Reference | `threshold_selection`: 학습 앞부분의 길이를 바꾸며 Threshold와 학습 자료 수 비교 |
| `compare_features.py` | 실제 입력·Reference | `feature_selection`: 논문식·Laplacian·Fisher 등 Feature 위치 선정 방식 비교 |

`reference_model.py`는 평가 스크립트가 호출하는 Reference 매칭·논문식 계산 함수이다.

## 실행 순서

```powershell
# 1. 보존된 원본 Sample 번호로 Reference 목록 재생성
python verification/training/audit_reference.py

# 2. Threshold 공식과 계수 Sweep
python verification/training/compare_thresholds.py

# 3. 학습 구간 길이와 Feature 선정 방식 비교
python verification/training/check_prefix.py
python verification/training/compare_features.py
```

입력 위치는 `--data-root`, 새 결과 위치는 `--output`으로 바꿀 수 있다. `compare_thresholds.py --check-only`는 입력과 Golden 일치만 검사한다.

## 자료 연결

- Reference 원본 Sample 번호: `data/recordings/<데이터>/reference_audit/public_spike_slice.npz`
- 출처 정보: 같은 폴더의 `public_datasets.json`
- 보존된 평가 결과: `results/training/threshold_sweep`, `threshold_selection`, `feature_selection`
- 선정 요약: `results/training/selection.txt`. 원본 상세 결과와 학습 기록: `results/training/details.zip`.

위 평가는 프로젝트에 보존한 원본 Sample 번호를 사용해 실행한다. 비교 코드는 보존된 Reference를 읽으며, 1번은 그 Reference를 원본 자료로 다시 만드는 절차이다.

평가는 같은 채널에서 허용 시간차 안의 Event를 일대일로 매칭한다. Threshold Sweep은 ±8·16·32 Sample을 확인하며, 주요 비교는 ±16 Sample이다.

`compare_thresholds.py`는 `all_candidates.csv`에 후보별 비교를 저장한다. Raw-noise 공식에서 세 Recording의 평균 Reference Recall이 가장 높은 계수를 고르고, 동률이면 검출 수가 적은 계수를 고른 결과가 `coefficient_selection.json`이다. 기존 실험의 공통 계수 14 선정 계산을 재현한다. F1 기준 결과는 `best_f1_formula.json`으로 구분한다.

Reference는 원본 Spike Sorting 결과이다. 매칭 수치는 이 Reference와의 일치도를 나타내며, 추가 검출의 실제 Spike 여부는 파형 검토가 필요하다. Reference Class는 Feature 비교 평가에 사용하고, 현재 `SW/python/train_config.py`는 Sample CSV만으로 학습한다.
