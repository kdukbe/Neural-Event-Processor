"""Reference-label matching and published saliency formulas for evaluation only."""
from __future__ import annotations
import math
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'SW/python'))
from processing import signal_model as base

ChannelSamples = base.ChannelSamples
Event = base.Event
DEFAULT_COEFFICIENTS = base.DEFAULT_COEFFICIENTS
CANDIDATE_OFFSETS = base.CANDIDATE_OFFSETS
read_input = base.read_input
aligned_feature_matrix = base.aligned_feature_matrix
valid_candidate_mask = base.valid_candidate_mask
set_channel_count = base.set_channel_count


def detect_events(*args, **kwargs):
    events, incomplete = base.detect_events(*args, **kwargs)
    for event in events:
        event.matched_gt_timestamp = -1
        event.spike_class = 0
        event.match_error = -1
    return events, incomplete


def ordered_match(
    detected: list[Event],
    ground_truth: list[dict[str, int]],
    tolerance: int,
) -> list[tuple[int, int]]:
    """Maximize one-to-one matches, then minimize total absolute time error."""
    count_a = len(detected)
    count_b = len(ground_truth)
    matches = np.zeros((count_a + 1, count_b + 1), dtype=np.int32)
    costs = np.zeros((count_a + 1, count_b + 1), dtype=np.int64)
    choice = np.zeros((count_a + 1, count_b + 1), dtype=np.int8)

    def better(candidate: tuple[int, int], current: tuple[int, int]) -> bool:
        return candidate[0] > current[0] or (
            candidate[0] == current[0] and candidate[1] < current[1]
        )

    for i in range(1, count_a + 1):
        for j in range(1, count_b + 1):
            best = (int(matches[i - 1, j]), int(costs[i - 1, j]))
            best_choice = 1  # skip detected event

            candidate = (int(matches[i, j - 1]), int(costs[i, j - 1]))
            if better(candidate, best):
                best = candidate
                best_choice = 2  # skip ground truth event

            error = abs(detected[i - 1].timestamp - ground_truth[j - 1]["timestamp"])
            if error <= tolerance:
                candidate = (
                    int(matches[i - 1, j - 1]) + 1,
                    int(costs[i - 1, j - 1]) + error,
                )
                if better(candidate, best) or candidate == best:
                    best = candidate
                    best_choice = 3

            matches[i, j], costs[i, j] = best
            choice[i, j] = best_choice

    pairs: list[tuple[int, int]] = []
    i, j = count_a, count_b
    while i > 0 and j > 0:
        if choice[i, j] == 3:
            pairs.append((i - 1, j - 1))
            i -= 1
            j -= 1
        elif choice[i, j] == 1:
            i -= 1
        else:
            j -= 1
    pairs.reverse()
    return pairs


def attach_labels(
    events: list[Event], ground_truth: list[dict[str, int]], tolerance: int
) -> int:
    matched_count = 0
    for channel in range(base.CHANNELS):
        event_channel = [event for event in events if event.channel_id == channel]
        truth_channel = sorted(
            (row for row in ground_truth if row["channel_id"] == channel),
            key=lambda row: row["timestamp"],
        )
        for event_index, truth_index in ordered_match(
            event_channel, truth_channel, tolerance
        ):
            event = event_channel[event_index]
            truth = truth_channel[truth_index]
            event.matched_gt_timestamp = truth["timestamp"]
            event.spike_class = truth["spike_class"]
            event.match_error = abs(event.timestamp - truth["timestamp"])
            matched_count += 1
    return matched_count


def class_log_saliency(values: np.ndarray, labels: np.ndarray) -> dict[int, np.ndarray]:
    """Implement Eqs. (5) and (6) of Shaeri and Sodagar, Nat. Commun. 2020."""
    classes = np.unique(labels)
    probabilities = {
        int(spike_class): float(np.mean(labels == spike_class))
        for spike_class in classes
    }
    means = {
        int(spike_class): values[labels == spike_class].mean(axis=0)
        for spike_class in classes
    }
    variances = {
        int(spike_class): values[labels == spike_class].var(axis=0)
        for spike_class in classes
    }

    result: dict[int, np.ndarray] = {}
    tiny = np.finfo(np.float64).tiny
    for spike_class in classes:
        class_id = int(spike_class)
        log_numerator = np.zeros(values.shape[1], dtype=np.float64)
        denominator_terms: list[np.ndarray] = []

        for other_class in classes:
            other_id = int(other_class)
            if other_id == class_id:
                continue
            distance_denominator = np.sqrt(
                probabilities[class_id] * variances[class_id]
                + probabilities[other_id] * variances[other_id]
            )
            # This is log(d_ij) from Eq. (5).  Working in log space avoids
            # numerical overflow from the exponential in the paper.
            log_distance = np.abs(means[class_id] - means[other_id]) / np.maximum(
                distance_denominator, tiny
            )
            log_numerator += probabilities[other_id] * log_distance
            denominator_terms.append(
                math.log(probabilities[other_id]) + log_distance
            )

        stacked = np.vstack(denominator_terms)
        maximum = np.max(stacked, axis=0)
        log_denominator = maximum + np.log(
            np.sum(np.exp(stacked - maximum), axis=0)
        )
        result[class_id] = 2.0 * log_numerator - log_denominator
    return result
