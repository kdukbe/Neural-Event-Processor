"""Compare feature-location alternatives without changing deployed configurations.

Run from project root: python verification/training/compare_features.py
Reference labels are incomplete sorter labels, not biological ground truth.
All method names and project adaptations are recorded in the output report.
"""
from __future__ import annotations
import argparse
import json
import math
from collections import Counter
from pathlib import Path
import numpy as np
import reference_model as sfe
from processing import threshold as threshold_model
from compare_thresholds import rows, sha, save_csv

ROOT = Path(__file__).resolve().parents[2]
DATA_ROOT = ROOT / 'data/recordings'
OUT = ROOT / 'build/training/feature_selection'
METHODS = ('printed_sfs', 'normalized_sfs', 'fisher', 'laplacian',
           'laplacian_corr', 'variance', 'uniform')
UNSUPERVISED = ('laplacian', 'laplacian_corr', 'variance', 'uniform')


def logsumexp(a, axis=0):
    m = np.max(a, axis=axis, keepdims=True)
    return np.squeeze(m + np.log(np.exp(a-m).sum(axis=axis, keepdims=True)), axis=axis)


def normalized_saliency(x, y):
    """Project correction: normalize OTHER-class weights in the two means.

    Eq.(5) keeps original empirical P_i/P_j. Eq.(6) uses q_j=P_j/(1-P_i).
    This is NOT claimed to reproduce the author's unpublished implementation.
    """
    classes = np.unique(y)
    p = {int(c): np.mean(y == c) for c in classes}
    mu = {int(c): x[y == c].mean(0) for c in classes}
    var = {int(c): x[y == c].var(0) for c in classes}
    result = {}
    floor = max(float(x.var(0).max()) * 1e-12, 1e-12)
    for i in classes:
        ds, weights = [], []
        for j in classes:
            if i == j:
                continue
            ds.append(np.abs(mu[i]-mu[j]) / np.sqrt(np.maximum(p[i]*var[i]+p[j]*var[j], floor)))
            weights.append(p[j]/(1-p[i]))
        ds, weights = np.asarray(ds), np.asarray(weights)
        result[int(i)] = 2*(weights[:, None]*ds).sum(0) - logsumexp(np.log(weights[:, None])+ds)
    return result


def laplacian_scores(x, neighbors=5):
    """He/Cai/Niyogi 2005, section 2.1, Eq.(1), symmetric kNN graph.

    k=5 and t=median positive connected squared distance are our settings.
    Feature scaling is unchanged: all candidate FIR samples have the same unit.
    """
    n = len(x)
    if n < 3:
        raise ValueError('At least three waveforms required for this experiment')
    k = min(neighbors, n-1)
    sq = ((x[:, None, :]-x[None, :, :])**2).sum(2)
    np.fill_diagonal(sq, np.inf)
    nn = np.argsort(sq, axis=1, kind='stable')[:, :k]
    edges = np.zeros((n, n), dtype=bool)
    edges[np.arange(n)[:, None], nn] = True
    edges |= edges.T
    distances = sq[edges]
    positive = distances[np.isfinite(distances) & (distances > 0)]
    if not len(positive):
        raise ValueError('No varying waveforms')
    scale = float(np.median(positive))
    s = np.zeros((n, n))
    s[edges] = np.exp(-sq[edges]/scale)
    d = s.sum(1)
    centered = x - (d[:, None]*x).sum(0)/d.sum()
    denominator = (d[:, None]*centered**2).sum(0)
    numerator = denominator - (centered*(s@centered)).sum(0)
    score = np.full(x.shape[1], np.inf)
    good = denominator > max(float(denominator.max())*1e-12, 1e-12)
    score[good] = np.maximum(numerator[good], 0)/denominator[good]
    return score, dict(k=k,heat_scale=scale,graph_edges=int(edges.sum()//2))


def fit(events, method, neighbors=5):
    training = list(events)
    if method not in UNSUPERVISED:
        counts = Counter(e.spike_class for e in events if e.spike_class > 0)
        keep = {c for c,n in counts.items() if n >= 2}
        training = [e for e in events if e.spike_class in keep]
        if len(keep) < 2:
            raise ValueError('fewer than two labeled classes with two examples')
    if len(training) < 3:
        raise ValueError('fewer than three training waveforms')
    x = sfe.aligned_feature_matrix(training)
    y = np.array([e.spike_class for e in training])
    mask = sfe.valid_candidate_mask(training)
    varying = x.var(0) > max(float(x.var(0).max())*1e-12, 1e-12)
    mask &= varying
    available = np.flatnonzero(mask)
    if len(available) < 2:
        raise ValueError('fewer than two nonconstant in-window candidate positions')
    meta = dict(training_events=len(training),valid_candidates=len(available),flat_classes=[])
    if method in ('printed_sfs', 'normalized_sfs'):
        scores = sfe.class_log_saliency(x,y) if method == 'printed_sfs' else normalized_saliency(x,y)
        union = []
        for c,score in scores.items():
            if np.ptp(score[mask]) <= 1e-10*max(1, float(np.max(np.abs(score[mask])))):
                meta['flat_classes'].append(int(c))
            chosen = []
            for _ in range(2):
                keys = []
                for col in available:
                    if col in chosen:
                        continue
                    value = float(score[col])
                    for previous in chosen:
                        a,b = x[y==c,col],x[y==c,previous]
                        rho = float(np.corrcoef(a,b)[0,1]) if a.std()>0 and b.std()>0 else 0
                        value += math.log(max(1-rho,1e-15))
                    keys.append((value,-abs(int(sfe.CANDIDATE_OFFSETS[col])),-int(sfe.CANDIDATE_OFFSETS[col]),int(col)))
                chosen.append(max(keys)[-1])
            union += [i for i in chosen if i not in union]
        if meta['flat_classes']:
            raise ValueError('flat saliency: class '+str(meta['flat_classes']))
        if len(union) > 7:
            raise ValueError('class union exceeds hardware seven slots')
        selected = union
    else:
        if method == 'fisher':
            center = x.mean(0)
            between,within = np.zeros(64),np.zeros(64)
            for c in np.unique(y):
                group = x[y==c]
                between += len(group)*(group.mean(0)-center)**2
                within += len(group)*group.var(0)
            rank_score = -between/np.maximum(within,max(float(within.max())*1e-12,1e-12))
        elif method.startswith('laplacian'):
            ls,graph = laplacian_scores(x[:,available],neighbors)
            meta.update(graph)
            rank_score = np.full(64,np.inf)
            rank_score[available] = ls
        elif method == 'variance':
            rank_score = -x.var(0)
        elif method == 'uniform':
            selected = available[np.linspace(0,len(available)-1,min(7,len(available)),dtype=int)].tolist()
        if method != 'uniform':
            ranked = sorted(available,key=lambda c:(rank_score[c],abs(int(sfe.CANDIDATE_OFFSETS[c])),int(sfe.CANDIDATE_OFFSETS[c])))
            selected = []
            for c in ranked:
                if not np.isfinite(rank_score[c]):
                    continue
                # Optional project addition, tested separately from the paper's ranking.
                if method == 'laplacian_corr' and any(abs(np.corrcoef(x[:,c],x[:,p])[0,1])>=0.95 for p in selected):
                    continue
                selected.append(int(c))
                if len(selected)==7:
                    break
    if len(selected)<2:
        raise ValueError('fewer than two selected positions')
    meta['offsets'] = [int(sfe.CANDIDATE_OFFSETS[c]) for c in selected]
    meta['feature_count'] = len(selected)
    return selected,meta


def predict_centroid(train, test, selected, nearest_neighbor=False):
    """Analysis-only classifier, no hardware module; no test labels used in fit."""
    xt, xv = sfe.aligned_feature_matrix(train)[:,selected], sfe.aligned_feature_matrix(test)[:,selected]
    yt = np.array([e.spike_class for e in train])
    if nearest_neighbor:
        return yt[np.argmin(((xv[:,None,:]-xt[None,:,:])**2).sum(2),axis=1)]
    cs = np.unique(yt)
    centers = np.array([xt[yt==c].mean(0) for c in cs])
    pred = cs[np.argmin(((xv[:,None,:]-centers[None,:,:])**2).sum(2),axis=1)]
    return pred


def heldout_neighbors(train,test,selected):
    """Same query/reference events; full eligible FIR-space vs selected values."""
    available = np.flatnonzero(sfe.valid_candidate_mask(train))
    xtr, xte = sfe.aligned_feature_matrix(train), sfe.aligned_feature_matrix(test)
    if not len(test):
        return None
    k = min(5,len(train))
    full = ((xte[:,None,available]-xtr[None,:,available])**2).sum(2)
    reduced = ((xte[:,None,selected]-xtr[None,:,selected])**2).sum(2)
    a,b = np.argsort(full,axis=1)[:,:k],np.argsort(reduced,axis=1)[:,:k]
    return float(np.mean([len(set(aa)&set(bb))/k for aa,bb in zip(a,b)]))


def unit_checks():
    x = np.array([[0,0,0],[1,3,1],[2,2,0],[1,1,1],
                  [7,0,0],[8,3,1],[9,2,0],[8,1,1]],float)
    y = np.repeat([1,2],4)
    for v in sfe.class_log_saliency(x,y).values():
        np.testing.assert_allclose(v,np.log(2),atol=1e-12)
    corrected = normalized_saliency(x,y)
    # Other-class q=1. Two-class corrected log-saliency equals log d.
    expected = np.abs(x[:4].mean(0)-x[4:].mean(0))/np.sqrt(.5*x[:4].var(0)+.5*x[4:].var(0))
    for v in corrected.values():
        np.testing.assert_allclose(v,expected,atol=1e-12)
        assert v[0]>v[1] and v[0]>v[2]
    ls,meta = laplacian_scores(x,2)
    # Independent double-sum Laplacian numerator, not the matrix shortcut.
    sq=((x[:,None,:]-x[None,:,:])**2).sum(2)
    np.fill_diagonal(sq,np.inf)
    nn=np.argsort(sq,axis=1,kind='stable')[:,:2]
    edge=np.zeros((8,8),bool);edge[np.arange(8)[:,None],nn]=True;edge|=edge.T
    s=np.zeros((8,8));s[edge]=np.exp(-sq[edge]/meta['heat_scale']);d=s.sum(1)
    centered=x-(x*d[:,None]).sum(0)/d.sum()
    direct=np.array([sum(s[i,j]*(x[i,c]-x[j,c])**2 for i in range(8) for j in range(8))/2
                     for c in range(3)])/(centered**2*d[:,None]).sum(0)
    np.testing.assert_allclose(ls,direct,atol=1e-12)
    return dict(printed_two_class_flat_reproduced=True,normalized_two_class_distance_verified=True,
                laplacian_matrix_matches_direct_sum=True)


def load_dataset(i):
    name='real'+str(i);folder=DATA_ROOT/name
    path=folder/'input.csv'
    threshold=threshold_model.calculate(path,samples_per_channel=20000)
    channels=sfe.read_input(path)
    events,incomplete=sfe.detect_events(name,channels,threshold['threshold'],63,sfe.DEFAULT_COEFFICIENTS)
    ref=folder/'reference_audit/reference_sample_indices.csv'
    truth=[{k:int(r[k]) for k in ('event_id','timestamp','channel_id','spike_class')}
           for r in rows(ref) if 0<=int(r['timestamp'])<30000]
    sfe.attach_labels(events,truth,16)
    return events,dict(dataset=name,threshold=threshold['threshold'],complete_windows=len(events),
                       incomplete_windows=incomplete,input_sha256=sha(path),reference_sha256=sha(ref))


def summarize(rows_in, groups):
    output=[]
    unique=sorted({tuple(r[g] for g in groups) for r in rows_in})
    for key in unique:
        subset=[r for r in rows_in if tuple(r[g] for g in groups)==key]
        valid=[r for r in subset if r.get('status')=='ok']
        correct=sum(r.get('correct',0) for r in valid);total=sum(r.get('tested',0) for r in valid)
        recalls=[]
        # Class-balanced mean within each channel, then equal weight per channel.
        buckets={}
        for r in valid:
            if 'true_class' in r:
                buckets.setdefault((r['dataset'],r['channel'],r['true_class']),[]).append(r['correct'])
        bychannel={}
        for (ds,ch,c),acc in buckets.items():bychannel.setdefault((ds,ch),[]).append(np.mean(acc))
        recalls=[np.mean(v) for v in bychannel.values()]
        out=dict(zip(groups,key));out.update(records=len(subset),ok=len(valid),correct=correct,tested=total,
            accuracy=correct/total if total else None,channel_macro_balanced_accuracy=float(np.mean(recalls)) if recalls else None)
        output.append(out)
    return output


def main():
    global OUT, DATA_ROOT
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root',type=Path,default=DATA_ROOT)
    parser.add_argument('--output',type=Path,default=OUT)
    args=parser.parse_args();OUT=args.output;DATA_ROOT=args.data_root
    OUT.mkdir(parents=True,exist_ok=True);sfe.set_channel_count(16)
    protected=list((ROOT/'HW/rtl').rglob('*.v'))+list((ROOT/'data').rglob('sfe_feature.csv'))
    before={str(p):sha(p) for p in protected}
    checks=unit_checks();all_status=[];loo=[];temporal=[];sources=[];configs=[];knn_sensitivity=[]
    for i in (1,2,3):
        events,source=load_dataset(i);sources.append(source);name=source['dataset']
        for ch in range(16):
            all_events=[e for e in events if e.channel_id==ch]
            # Nonoverlapping windows around the time split: do not share samples.
            prefix=[e for e in all_events if e.sample_index+31<20000]
            future=[e for e in all_events if e.sample_index-32>=20000]
            known=[e for e in all_events if e.spike_class>0]
            class_counts=Counter(e.spike_class for e in known)
            eligible_classes={c for c,n in class_counts.items() if n>=3}
            for method in METHODS:
                for range_name,training in [('prefix',prefix),('full',all_events)]:
                    base=dict(dataset=name,channel=ch,method=method,range=range_name,
                              detected_train=len(training),known_train=sum(e.spike_class>0 for e in training))
                    try:
                        selected,meta=fit(training,method)
                        base.update(meta,status='ok')
                        # Address guards follow existing RTL. Report future out-of-window values.
                        eval_events=future if range_name=='prefix' else all_events
                        addresses=np.array([e.max_slope_index for e in eval_events])[:,None]+np.array(meta['offsets'])[None,:]
                        base['eval_events']=len(eval_events)
                        base['out_of_window_values']=int(((addresses<0)|(addresses>=64)).sum())
                        base['out_of_window_fraction']=float(((addresses<0)|(addresses>=64)).mean()) if addresses.size else None
                        if range_name=='prefix':
                            if method in UNSUPERVISED:
                                base['heldout_neighbor_recall5']=heldout_neighbors(training,future,selected)
                            trknown=[e for e in prefix if e.spike_class>0]
                            counts=Counter(e.spike_class for e in trknown);cs={c for c,n in counts.items() if n>=2}
                            trknown=[e for e in trknown if e.spike_class in cs]
                            teknown=[e for e in future if e.spike_class in cs]
                            base['unseen_future_labels']=sum(e.spike_class>0 and e.spike_class not in cs for e in future)
                            if len(cs)>=2 and teknown:
                                pred=predict_centroid(trknown,teknown,selected)
                                pred_nn=predict_centroid(trknown,teknown,selected,True)
                                for e,p,pn in zip(teknown,pred,pred_nn):
                                    temporal.append(dict(dataset=name,channel=ch,method=method,true_class=e.spike_class,
                                        timestamp=e.timestamp,predicted=int(p),correct=int(p==e.spike_class),
                                        predicted_nn=int(pn),correct_nn=int(pn==e.spike_class),tested=1,status='ok'))
                        if method=='laplacian':
                            # Candidate only; includes full data sources and selected-count metadata.
                            padded=meta['offsets']+[0]*(7-len(selected))
                            configs.append(dict(dataset=name,range=range_name,channel_id=ch,
                                feature_count=len(selected),feature_flag=format((1<<len(selected))-1,'07b'),
                                **{f'offset{k}':v for k,v in enumerate(padded)}))
                    except ValueError as error:
                        base.update(status='unavailable',reason=str(error))
                    all_status.append(base)
                # Outer leave-one-event-out: no held-out waveform in feature fit.
                # Labels are used only for the supervised candidates and classifier.
                if len(eligible_classes)>=2:
                    for heldout in [e for e in known if e.spike_class in eligible_classes]:
                        train_events=[e for e in all_events if e is not heldout and abs(e.sample_index-heldout.sample_index)>=64]
                        train_known=[e for e in train_events if e.spike_class in eligible_classes]
                        counts=Counter(e.spike_class for e in train_known)
                        base=dict(dataset=name,channel=ch,method=method,true_class=heldout.spike_class,
                                  timestamp=heldout.timestamp,tested=0,correct=0)
                        if any(counts[c]<2 for c in eligible_classes):
                            base.update(status='unavailable',reason='class too small after window exclusion')
                        else:
                            try:
                                selected,meta=fit(train_events,method)
                                p=int(predict_centroid(train_known,[heldout],selected)[0])
                                pn=int(predict_centroid(train_known,[heldout],selected,True)[0])
                                base.update(status='ok',tested=1,correct=int(p==heldout.spike_class),predicted=p,
                                            predicted_nn=pn,correct_nn=int(pn==heldout.spike_class),feature_count=len(selected))
                            except ValueError as error:base.update(status='unavailable',reason=str(error))
                        loo.append(base)
            for k in (3,5,10):
                try:
                    selected,meta=fit(prefix,'laplacian',k)
                    knn_sensitivity.append(dict(dataset=name,channel=ch,k=k,status='ok',
                        offsets=meta['offsets'],feature_count=len(selected),
                        heldout_neighbor_recall5=heldout_neighbors(prefix,future,selected)))
                except ValueError as error:knn_sensitivity.append(dict(dataset=name,channel=ch,k=k,status='unavailable',reason=str(error)))
        print(name,'completed; windows',len(events),flush=True)
    assert before=={str(p):sha(p) for p in protected}
    # Compare only identical held-out examples across all non-printed candidates.
    core_methods=set(METHODS)-{'printed_sfs'}
    fold_methods={}
    for r in loo:
        if r['status']=='ok':fold_methods.setdefault((r['dataset'],r['channel'],r['timestamp']),set()).add(r['method'])
    common={key for key,methods in fold_methods.items() if core_methods<=methods}
    common_rows=[r for r in loo if (r['dataset'],r['channel'],r['timestamp']) in common and r['method'] in core_methods]
    report=dict(protected_files_unchanged=True,protected_count=len(before),checks=checks,sources=sources,
        threshold_prefix_samples_per_channel=20000,feature_prefix_samples_per_channel=20000,
        candidate_selection='maximum 7 nonconstant offsets, valid for every training window; no invented labels',
        original_sfs='original formula, 2 per class then union; flat scores explicitly rejected',
        normalized_sfs='project-derived normalized other-class weights, NOT an author-confirmed correction',
        laplacian='He/Cai/Niyogi 2005 Eq.1. k=5, t=median positive neighbor squared distance, lowest scores',
        laplacian_corr='optional project addition: skip |rho| >= 0.95; not the original paper algorithm',
        fisher='He/Cai/Niyogi 2005 Eq.4, top seven; no correlation penalty',
        evaluation='Analysis-only Euclidean nearest-centroid classifier. Incomplete curated IBL labels. Not SD accuracy.',
        loo_summary=summarize(loo,['method']),loo_by_dataset=summarize(loo,['dataset','method']),
        common_loo_summary=summarize(common_rows,['method']),common_heldout_count=len(common),
        common_loo_nearest_neighbor_summary=summarize([{**r,'correct':r.get('correct_nn',0)} for r in common_rows],['method']),
        temporal_summary=summarize(temporal,['method']),temporal_by_dataset=summarize(temporal,['dataset','method']),
        temporal_nearest_neighbor_summary=summarize([{**r,'correct':r.get('correct_nn',0)} for r in temporal],['method']),
        statuses=all_status,neighbor_sensitivity=knn_sensitivity)
    (OUT/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    for filename,values in [('channel_status.csv',all_status),('loo_predictions.csv',loo),
                            ('temporal_predictions.csv',temporal),('laplacian_candidates.csv',configs),
                            ('neighbor_sensitivity.csv',knn_sensitivity)]:
        serialized=[{k:json.dumps(v) if isinstance(v,(dict,list)) else v for k,v in r.items()} for r in values]
        fields=list(dict.fromkeys(k for r in serialized for k in r))
        save_csv(OUT/filename,[{k:r.get(k,'') for k in fields} for r in serialized])
    print(json.dumps({k:report[k] for k in ['checks','common_heldout_count','common_loo_summary','temporal_summary']},indent=2),flush=True)
    print('PASS: protected RTL/config unchanged; exploratory files only',flush=True)


if __name__=='__main__':
    main()
