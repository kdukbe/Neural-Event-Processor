create_clock -name input_clk -period 2500.000 [get_ports s_clk]
create_clock -name main_clk  -period 62.500 [get_ports clk]
create_clock -name sfe_clk   -period 100.000 [get_ports sfe_clk]

set_clock_groups -asynchronous \
    -group [get_clocks input_clk] \
    -group [get_clocks main_clk] \
    -group [get_clocks sfe_clk]
