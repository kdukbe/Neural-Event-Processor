set observed_clock_edges 134890
set observed_clock_period_ns 17840.907406034548
set observed_clock_high_ns 62.500000000000
