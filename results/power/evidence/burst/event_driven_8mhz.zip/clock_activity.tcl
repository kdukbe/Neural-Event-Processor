set observed_clock_edges 72198
set observed_clock_period_ns 2360.176182165711
set observed_clock_high_ns 62.500000000000
