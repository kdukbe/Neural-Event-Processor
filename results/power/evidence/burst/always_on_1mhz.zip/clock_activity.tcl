set observed_clock_edges 170400
set observed_clock_period_ns 1000.000000000000
set observed_clock_high_ns 500.000000000000
