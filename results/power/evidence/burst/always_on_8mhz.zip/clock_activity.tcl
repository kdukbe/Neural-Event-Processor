set observed_clock_edges 1363200
set observed_clock_period_ns 125.000000000000
set observed_clock_high_ns 62.500000000000
