set observed_clock_edges 131480
set observed_clock_period_ns 18303.620322482508
set observed_clock_high_ns 62.500000000000
