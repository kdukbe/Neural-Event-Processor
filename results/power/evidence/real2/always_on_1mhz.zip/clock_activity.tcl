set observed_clock_edges 2406560
set observed_clock_period_ns 1000.000000000000
set observed_clock_high_ns 500.000000000000
