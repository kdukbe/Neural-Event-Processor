set observed_clock_edges 71926
set observed_clock_period_ns 33458.832689152739
set observed_clock_high_ns 62.500000000000
