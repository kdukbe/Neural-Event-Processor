set observed_clock_edges 19252480
set observed_clock_period_ns 125.000000000000
set observed_clock_high_ns 62.500000000000
